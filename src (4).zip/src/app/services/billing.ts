// Plan y créditos del NEGOCIO (no de cada usuario).
//
// El servidor es quien decide: cada ruta de la API revisa si el negocio tiene vigente la
// función a la que pertenece y, si no, responde 402. Este servicio solo guarda una copia del
// estado (billing/status) para que la app sepa qué mostrar con candado en el menú y a qué
// pantallas no entrar, y la vuelve a pedir:
//   · al iniciar sesión,
//   · cada 2 minutos mientras la app está abierta (así un desbloqueo por horas se vuelve a
//     bloquear sin recargar),
//   · cuando el servidor responde 402 (venció algo a media sesión),
//   · después de contratar, comprar créditos o desbloquear.
import { Injectable } from '@angular/core';
import axios from 'axios';
import { ApiService } from './api';

export interface BillingFeature {
  key: string;
  name: string;
  description: string;
  credits_per_hour: number | null;
  credits_per_day: number | null;
  in_plan: boolean;
  unlocked_until: string | null;
  active: boolean;
}

export interface BillingPlan {
  code: string;
  name: string;
  description: string;
  monthly_price: number;
  annual_price: number;
  max_users: number | null;
  features: string[];
}

export interface BillingStatus {
  business: { id: number; name: string };
  now: string;
  credits: number;
  payment_mode: 'simulated' | 'manual';
  currency: string;
  bank_info: string;
  // Plan gratuito: el que tiene el negocio cuando no hay uno de paga vigente (no se contrata ni vence)
  free_plan: string | null;
  effective_plan: { code: string; name: string } | null;
  subscription: null | {
    id: number;
    plan_code: string;
    plan_name: string;
    cycle: 'monthly' | 'annual' | 'trial' | 'gift';
    price: number;
    starts_at: string;
    ends_at: string;
    paid_until: string;
    days_left: number;
    // Cancelado: sigue vigente hasta ends_at (el fin del mes en curso) y después pasa al Plan gratuito
    cancel_requested_at: string | null;
    // Si se cancelara hoy: hasta cuándo seguiría y cuántos créditos se devolverían
    // (ya cancelado: su fecha de fin y los créditos que se devolvieron)
    cancel_at: string;
    cancel_refund: number;
    // Créditos que se abonarían hoy al cambiar a otro plan (lo que sobra del actual)
    change_refund: number;
  };
  // Regla de devolución: `credits` créditos por cada `pesos` pesos del tiempo que sobraba
  refund_rule?: { pesos: number; credits: number };
  last_plan: null | { plan_code: string; ends_at: string };
  queued: { id: number; plan_code: string; cycle: string; starts_at: string; ends_at: string }[];
  users: { active: number; max: number | null };
  features: BillingFeature[];
  plans: BillingPlan[];
  packages: { id: number; name: string; credits: number; bonus: number; price: number }[];
  pending_payments: { id: number; concept: string; description: string; amount: number; method: string; reference: string | null; created_at: string }[];
}

const KEY = 'billing';
export const BILLING_EVENT = 'la-obra-billing-updated';
const REFRESH_MS = 2 * 60 * 1000;

@Injectable({ providedIn: 'root' })
export class BillingService {
  private timer: any = null;
  private inFlight: Promise<BillingStatus | null> | null = null;

  constructor(private api: ApiService) {
    // Si el servidor bloquea algo (402 por plan o créditos), se actualiza el estado guardado
    axios.interceptors.response.use(
      r => r,
      error => {
        const d = error?.response?.data;
        if (error?.response?.status === 402 && d?.plan_required && !String(error?.config?.url || '').includes('/billing/')) {
          void this.refresh();
        }
        return Promise.reject(error);
      }
    );
    this.timer = setInterval(() => {
      if (localStorage.getItem('token') && document.visibilityState !== 'hidden') void this.refresh();
    }, REFRESH_MS);
  }

  // Estado guardado (puede ser null antes de iniciar sesión)
  get status(): BillingStatus | null {
    try {
      return JSON.parse(localStorage.getItem(KEY) || 'null');
    } catch {
      return null;
    }
  }

  set(status: BillingStatus | null) {
    if (status) localStorage.setItem(KEY, JSON.stringify(status));
    else localStorage.removeItem(KEY);
    window.dispatchEvent(new CustomEvent(BILLING_EVENT));
  }

  clear() {
    this.set(null);
  }

  // Pide el estado al servidor. Si falla (sin red) se queda el último que se conoce.
  refresh(): Promise<BillingStatus | null> {
    if (!localStorage.getItem('token')) return Promise.resolve(null);
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.api
      .get('billing/status.php')
      .then(r => {
        this.set(r.billing);
        return r.billing as BillingStatus;
      })
      .catch(() => this.status)
      .finally(() => (this.inFlight = null));
    return this.inFlight;
  }

  // Planes y créditos quedan solo como pantalla de muestra (trabajo de la escuela):
  // ninguna función se bloquea. El servidor tampoco bloquea (supabase/15_dinero_reparto_encargos.sql).
  isActive(_feature: string | undefined | null): boolean {
    return true;
  }

  feature(key: string): BillingFeature | undefined {
    return this.status?.features.find(f => f.key === key);
  }

  // Llamadas que cambian el plan o los créditos (solo administradores)
  // Solo se paga con tarjeta (modo de prueba, sin pedir datos)
  async subscribe(plan_code: string, cycle: 'monthly' | 'annual') {
    const r = await this.api.post('billing/subscribe.php', { plan_code, cycle, method: 'card_test' });
    this.set(r.billing);
    return r;
  }

  async buyCredits(package_id: number) {
    const r = await this.api.post('billing/buy-credits.php', { package_id, method: 'card_test' });
    this.set(r.billing);
    return r;
  }

  async unlock(feature: string, unit: 'hour' | 'day', quantity: number) {
    const r = await this.api.post('billing/unlock.php', { feature, unit, quantity });
    this.set(r.billing);
    return r;
  }

  // Cancelar el plan al final del periodo (y deshacerlo mientras siga vigente)
  async cancelPlan(reason = '') {
    const r = await this.api.post('billing/cancel.php', { reason });
    this.set(r.billing);
    return r;
  }

  async resumePlan() {
    const r = await this.api.post('billing/resume.php', {});
    this.set(r.billing);
    return r;
  }

  async cancelPayment(id: number) {
    const r = await this.api.post('billing/cancel-payment.php', { id });
    this.set(r.billing);
    return r;
  }

  history() {
    return this.api.get('billing/history.php');
  }
}
