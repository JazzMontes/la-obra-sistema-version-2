// Rutas de la aplicación. Las de configuración y análisis son solo para administradores.
// useHash: las direcciones quedan como .../#/pos. Así GitHub Pages (que no tiene reglas de
// reescritura) nunca da 404 al recargar una pantalla, y no hace falta --base-href ni 404.html.
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { adminGuard, authGuard } from './services/guards';

// Los planes ya no bloquean pantallas: solo se pide sesión (y rol de administrador donde aplica)
const page = (path: string, load: () => Promise<any>, admin = false, _feature?: string) => ({
  path,
  loadChildren: load,
  canActivate: [admin ? adminGuard : authGuard],
});

const routes: Routes = [
  { path: 'login', loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule) },
  { path: 'data-origins', loadChildren: () => import('./pages/data-origins/data-origins.module').then(m => m.DataOriginsPageModule) },
  { path: 'change-password', loadChildren: () => import('./pages/change-password/change-password.module').then(m => m.ChangePasswordPageModule) },

  page('home', () => import('./home/home.module').then(m => m.HomePageModule)),
  page('pos', () => import('./pages/pos/pos.module').then(m => m.PosPageModule), false, 'ventas'),
  page('orders', () => import('./pages/orders/orders.module').then(m => m.OrdersPageModule), false, 'ventas'),
  page('cash-cut', () => import('./pages/cash-cut/cash-cut.module').then(m => m.CashCutPageModule), false, 'ventas'),
  page('inventory', () => import('./pages/inventory/inventory.module').then(m => m.InventoryPageModule), false, 'inventario'),
  page('waste', () => import('./pages/waste/waste.module').then(m => m.WastePageModule), false, 'inventario'),
  page('expenses', () => import('./pages/expenses/expenses.module').then(m => m.ExpensesPageModule), false, 'gastos'),
  page('attendance', () => import('./pages/attendance/attendance.module').then(m => m.AttendancePageModule), false, 'asistencia'),
  page('profile', () => import('./pages/profile/profile.module').then(m => m.ProfilePageModule)),
  // Notas y recordatorios: para todos y en cualquier plan
  page('notes', () => import('./pages/notes/notes.module').then(m => m.NotesPageModule)),
  page('billing', () => import('./pages/billing/billing.module').then(m => m.BillingPageModule)),
  page('student-validation', () => import('./pages/student-validation/student-validation.module').then(m => m.StudentValidationPageModule)),

  page('purchases', () => import('./pages/purchases/purchases.module').then(m => m.PurchasesPageModule), true, 'inventario'),
  page('products', () => import('./pages/products/products.module').then(m => m.ProductsPageModule), true, 'ventas'),
  page('preparations', () => import('./pages/preparations/preparations.module').then(m => m.PreparationsPageModule), true, 'recetas'),
  page('inputs', () => import('./pages/inputs/inputs.module').then(m => m.InputsPageModule), true, 'inventario|recetas'),
  page('categories', () => import('./pages/categories/categories.module').then(m => m.CategoriesPageModule), true, 'ventas'),
  page('costs', () => import('./pages/costs/costs.module').then(m => m.CostsPageModule), true, 'recetas'),
  page('reports', () => import('./pages/reports/reports.module').then(m => m.ReportsPageModule), true, 'reportes'),
  page('money', () => import('./pages/money/money.module').then(m => m.MoneyPageModule), true),
  page('money-settings', () => import('./pages/money-settings/money-settings.module').then(m => m.MoneySettingsPageModule), true),
  page('users', () => import('./pages/users/users.module').then(m => m.UsersPageModule), true),
  page('payment-methods', () => import('./pages/payment-methods/payment-methods.module').then(m => m.PaymentMethodsPageModule), true, 'ventas'),

  // Rutas anteriores
  { path: 'sales', redirectTo: 'pos', pathMatch: 'full' },
  { path: 'recipes', redirectTo: 'products', pathMatch: 'full' },
  { path: 'corte', redirectTo: 'cash-cut', pathMatch: 'full' },

  // La app siempre abre en el inicio de sesión
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
