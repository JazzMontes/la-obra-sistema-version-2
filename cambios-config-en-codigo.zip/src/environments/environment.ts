// Configuración para desarrollo (`ng serve` / `ionic serve`).
// Pon los mismos datos de Supabase que en environment.prod.ts.

export const environment = {
  production: false,
  supabaseUrl: '',
  supabaseKey: '',
  controlEscolarUrl: 'http://192.168.1.158/control_escolar_api/api/integration/validar-alumno.php',
};
